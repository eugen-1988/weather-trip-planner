const TripDetails = () => {
  return <div>TripDetails</div>;
};
export default TripDetails;
