const NewTrip = () => {
  return <div>NewTrip</div>;
};
export default NewTrip;
