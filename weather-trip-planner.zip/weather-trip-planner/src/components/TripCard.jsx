const TripCard = () => {
  return <div>TripCard</div>;
};
export default TripCard;
