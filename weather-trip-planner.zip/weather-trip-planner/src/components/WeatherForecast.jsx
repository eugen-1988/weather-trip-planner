const WeatherForecast = () => {
  return <div>WeatherForecast</div>;
};
export default WeatherForecast;
