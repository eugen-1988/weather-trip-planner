const Header = () => {
  return <div className="bg-red-50">Header</div>;
};
export default Header;
